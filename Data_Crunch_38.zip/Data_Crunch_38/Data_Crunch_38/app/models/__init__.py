"""
Models package for AgroChill
"""